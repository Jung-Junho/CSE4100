/* $begin shellmain */
#include "myshell.h"
#include<errno.h>
#define MAXARGS   128

/* Function prototypes */
void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv);
void pipeline(char ***args, int pipeline_num);
int argCounter(char **argv);
int pipelineCounter(char **argv, int argc);
char ***cmdParse(char **argv, int argc);

int main() 
{
    char cmdline[MAXLINE]; /* Command line */

    while (1) {
	/* Read */
	printf("CSE4100-SP-P2>");                   
	fgets(cmdline, MAXLINE, stdin); 
	if (feof(stdin))
	    exit(0);

	/* Evaluate */
	eval(cmdline);
    }
}
/* $end shellmain */

/* $begin pipeline */
void pipeline(char ***args, int pipeline_num) {
    int cmd_num = pipeline_num + 1;
    pid_t pid[cmd_num];
    int pipe_fd[cmd_num-1][2];

    for (int i = 0; i < cmd_num; i++) {
        //create pipe
        if (i < cmd_num - 1 && pipe(pipe_fd[i]) == -1) {
            perror("pipe");
            exit(EXIT_FAILURE);
        }

        pid[i] = fork();
        //fork error
        if (pid[i] == -1) {
            perror("fork");
            exit(EXIT_FAILURE);
        }

        //child process
        else if (pid[i] == 0) {
            // If not the first command, prev output -> curr input
            if (i > 0) {
                Close(pipe_fd[i-1][1]);
                Dup2(pipe_fd[i-1][0], STDIN_FILENO);
                Close(pipe_fd[i-1][0]);
            }
            // If not the last command, curr output -> next input
            if (i < cmd_num - 1) {
                Close(pipe_fd[i][0]);
                Dup2(pipe_fd[i][1], STDOUT_FILENO);
                Close(pipe_fd[i][1]);
            }

            char *argv_n;   // argv_n : /bin/argv[0]
            argv_n = calloc(MAXARGS, sizeof(char));
            strcpy(argv_n, "/bin/");
            strcat(argv_n, args[i][0]);

            if (execve(args[i][0], args[i], environ) < 0) {
                if (execve(argv_n, args[i], environ) < 0) {	//ex) /bin/ls ls -al &
                    free(argv_n);
                    printf("%s: Command not found.\n", args[i][0]);
                    exit(0);
                }
            }
        }

        // parent process
        if (i > 0) {
            Close(pipe_fd[i-1][0]);
            Close(pipe_fd[i-1][1]);
        }
    }

    for (int i = 0; i < cmd_num; i++) {
        int status;
        if(waitpid(pid[i],&status,0)<0) unix_error("waitfg: waitpid error");
    }
    return;
}
/* $end pipeline */

/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline) 
{
    char *argv[MAXARGS]; /* Argument list execve() */
    char buf[MAXLINE];   /* Holds modified command line */
    int bg;              /* Should the job run in bg or fg? */
    pid_t pid;           /* Process id */
    
    char ***cmd;
    int argc;   // number of argv
    int pipeline_num;    // number of pipeline

    strcpy(buf, cmdline);
    bg = parseline(buf, argv); 
    if (argv[0] == NULL)
        return;   /* Ignore empty lines */
    if (!builtin_command(argv)) { //quit -> exit(0), & -> ignore, other -> run
        argc = argCounter(argv);
        pipeline_num = pipelineCounter(argv, argc);

        if (pipeline_num) {
            cmd = cmdParse(argv, argc);
            pipeline(cmd, pipeline_num);
            //free
            for (int i = 0; i < argc; i++) {
                free(cmd[i]);
            }
            free(cmd);
        }
        else if ((pid = fork()) == 0) { // child process
            char *argv_n;   // argv_n : /bin/argv[0]
            argv_n = calloc(MAXARGS, sizeof(char));
            strcpy(argv_n, "/bin/");
            strcat(argv_n, argv[0]);

            if (execve(argv_n, argv, environ) < 0) {	//ex) /bin/ls ls -al &
                free(argv_n);
                printf("%s: Command not found.\n", argv[0]);
                exit(0);
            }
        }

	/* Parent waits for foreground job to terminate */
	if (!bg){ 
	    int status;
        if(waitpid(pid,&status,0)<0 && !pipeline_num) unix_error("waitfg: waitpid error");
	}
	else//when there is backgrount process!
	    printf("%d %s", pid, cmdline);
    }
    return;
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(char **argv) 
{
    if (!strcmp(argv[0], "quit")) /* quit command */
	    exit(0);
    if (!strcmp(argv[0], "exit"))
        exit(0);
    if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
	    return 1;
    if (!strcmp(argv[0], "cd")) {   // cd command
        if (argv[1]) {
            if (chdir(argv[1]))
                perror("cd");
        }
        else chdir(getenv("HOME")); 
        return 1;
    }
    return 0;                     /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, char **argv) 
{
    char *delim;         /* Points to first space delimiter */
    int argc;            /* Number of args */
    int bg;              /* Background job? */

    buf[strlen(buf)-1] = ' ';  /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
	buf++;

    /* Build the argv list */
    argc = 0;
    while ((delim = strchr(buf, ' '))) {
        // Ignore ', "
        if (*buf == '\'') {
            buf++;
            delim = strchr(buf, '\'');
        }
        else if (*buf == '\"') {
            buf++;
            delim = strchr(buf, '\"');
        }
    	argv[argc++] = buf;
    	*delim = '\0';
    	buf = delim + 1;
    	while (*buf && (*buf == ' ')) /* Ignore spaces */
            buf++;
    }
    argv[argc] = NULL;
    
    if (argc == 0)  /* Ignore blank line */
	return 1;

    /* Should the job run in the background? */
    if ((bg = (*argv[argc-1] == '&')) != 0)
	argv[--argc] = NULL;

    return bg;
}
/* $end parseline */

int argCounter(char **argv) {
    int cnt = 0;
    while(argv[cnt] != NULL) {
        cnt++;
    }
    return cnt + 1;
}

int pipelineCounter(char **argv, int argc) {
    int cnt = 0;
    for (int i = 0; i < argc - 1; ++i) {
        if (!strcmp(argv[i], "|")) {
            cnt++;
        }
    }
    return cnt;
}

char ***cmdParse(char **argv, int argc) {
    // allocate & Init
    char ***cmd = malloc(argc * sizeof(char**));
    for (int i = 0; i < argc; i++) {
        cmd[i] = malloc(MAXARGS * sizeof(char*));
        for (int j = 0; j < MAXARGS; j++) {
            cmd[i][j] = NULL;
        }
    }

    int i, j, k;
    i = j = k = 0;
    while (i < argc) {
        while (argv[i] != NULL && argv[i] != '\'' && argv[i] != '/"' && strcmp(argv[i], "|")) {
            cmd[j][k] = argv[i];
            i++;
            k++;
        }
        cmd[j][k] = NULL;
        i++;
        j++;
        k = 0;
    }
    cmd[j] = NULL;
    return cmd;
}
