/* $begin shellmain */
#include "myshell.h"
#include<errno.h>
#define MAXARGS   128
#define MAXJOBS 1024

int job_cnt = 0;

int next_jid = 1;
enum JOB_STATE {
    UNDEF,
    FG,
    BG,
    ST,
    DONE,
    KILL,
};

typedef struct _job_t {
    pid_t pid;  // job pid
    int jid;    // job id
    int state;
    char cmdline[MAXLINE];
} job_t;

const char *state_c[] = {
    "dummy",
    "foreground",
    "background",
    "suspended"
};

job_t jobs[MAXJOBS];

/* Function prototypes */
// phase1
void eval(char *cmdline);
int parseline(char *buf, char **argv, char *jobs_cmdline);
int builtin_command(char **argv);
// phase2
void pipeline(char ***args, int pipeline_num);
int argCounter(char **argv);
int pipelineCounter(char **argv, int argc);
char ***cmdParse(char **argv, int argc);
// phase3
void jobsCmd();
void killCmd(char **argv);
void fgbgCmd(char **argv);

void InitJob(job_t *job);
int AddJob(job_t *jobs, pid_t pid, int state, char *cmdline);
int UpdateJob(); // Afer kill, fg, bg, Update 
job_t *getJobByPID(job_t *job, pid_t pid);
job_t *getJobByJID(job_t *job, int jid);
pid_t fgpid(job_t *job);
void sigintHandler(int sig);
void sigtstpHandler(int sig);
void sigchldHandler(int sig);

int main() 
{
    char cmdline[MAXLINE]; /* Command line */
    Signal(SIGINT, sigintHandler);
    Signal(SIGTSTP, sigtstpHandler);
    Signal(SIGCHLD, sigchldHandler);

    // init job
    for (int i = 0; i < MAXJOBS; i++) {
        InitJob(&jobs[i]);
    }

    while (1) {
	    /* Read */
	    printf("CSE4100-SP-P2>");                   
	    fgets(cmdline, MAXLINE, stdin); 
	    if (feof(stdin))
	        exit(0);

	    /* Evaluate */
	    eval(cmdline);
        UpdateJob();
    }
}
/* $end shellmain */

/* $begin pipeline */
void pipeline(char ***args, int pipeline_num) {
    int cmd_num = pipeline_num + 1;
    pid_t pid[cmd_num];
    int pipe_fd[cmd_num-1][2];

    for (int i = 0; i < cmd_num; i++) {
        //create pipe
        if (i < cmd_num - 1 && pipe(pipe_fd[i]) == -1) {
            perror("pipe");
            exit(EXIT_FAILURE);
        }

        pid[i] = fork();
        //fork error
        if (pid[i] == -1) {
            perror("fork");
            exit(EXIT_FAILURE);
        }

        //child process
        else if (pid[i] == 0) {
            // If not the first command, prev output -> curr input
            if (i > 0) {
                Close(pipe_fd[i-1][1]);
                Dup2(pipe_fd[i-1][0], STDIN_FILENO);
                Close(pipe_fd[i-1][0]);
            }
            // If not the last command, curr output -> next input
            if (i < cmd_num - 1) {
                Close(pipe_fd[i][0]);
                Dup2(pipe_fd[i][1], STDOUT_FILENO);
                Close(pipe_fd[i][1]);
            }

            char *argv_n;   // argv_n : /bin/argv[0]
            argv_n = calloc(MAXARGS, sizeof(char));
            strcpy(argv_n, "/bin/");
            strcat(argv_n, args[i][0]);

            if (execve(args[i][0], args[i], environ) < 0) {
                if (execve(argv_n, args[i], environ) < 0) {	//ex) /bin/ls ls -al &
                    free(argv_n);
                    printf("%s: Command not found.\n", args[i][0]);
                    exit(0);
                }
            }
        }

        // parent process
        if (i > 0) {
            Close(pipe_fd[i-1][0]);
            Close(pipe_fd[i-1][1]);
        }
    }

    for (int i = 0; i < cmd_num; i++) {
        int status;
        if(waitpid(pid[i],&status,0)<0) unix_error("waitfg: waitpid error");
    }
    return;
}
/* $end pipeline */

/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline) 
{
    char *argv[MAXARGS]; /* Argument list execve() */
    char buf[MAXLINE];   /* Holds modified command line */
    int bg;              /* Should the job run in bg or fg? */
    pid_t pid;           /* Process id */
    
    char jobs_cmdline[MAXLINE] = "";    
    char ***cmd;
    int argc;   // number of argv
    int pipeline_num;    // number of pipeline


    strcpy(buf, cmdline);
    bg = parseline(buf, argv, jobs_cmdline); 
    if (argv[0] == NULL)
        return;   /* Ignore empty lines */
    if (!builtin_command(argv)) { //quit -> exit(0), & -> ignore, other -> run
        argc = argCounter(argv);
        pipeline_num = pipelineCounter(argv, argc);

        // pipe
        if (pipeline_num) {
            cmd = cmdParse(argv, argc);
            pipeline(cmd, pipeline_num);
            //free
            for (int i = 0; i < argc; i++) {
                free(cmd[i]);
            }
            free(cmd);
        }

        else if ((pid = fork()) == 0) { // child process
            char *argv_n;   // argv_n : /bin/argv[0]
            argv_n = calloc(MAXARGS, sizeof(char));
            strcpy(argv_n, "/bin/");
            strcat(argv_n, argv[0]);

            if (execve(argv[0], argv, environ) < 0) {
                if (execve(argv_n, argv, environ) < 0) {	//ex) /bin/ls ls -al &
                    free(argv_n);
                    printf("%s: Command not found.\n", argv[0]);
                    exit(0);
                }
            }
        }

	    /* Parent waits for foreground job to terminate */
	    if (!bg){ 
	        int status;
            if (!WIFEXITED(status)) {
                AddJob(jobs, pid, FG, jobs_cmdline);
            }
            if(waitpid(pid,&status,0)<0 && !pipeline_num) unix_error("waitfg: waitpid error");
	    }
    	else {
            AddJob(jobs, pid, BG, jobs_cmdline); 
        }
    }
    return;
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(char **argv) 
{
    if (!strcmp(argv[0], "quit")) /* quit command */
	    exit(0);
    if (!strcmp(argv[0], "exit"))
        exit(0);
    if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
	    return 1;
    if (!strcmp(argv[0], "cd")) {   // cd command
        if (argv[1]) {
            if (chdir(argv[1]))
                perror("cd");
        }
        else chdir(getenv("HOME")); 
        return 1;
    }
    if (!strcmp(argv[0], "jobs")) {  // job command
        jobsCmd();
        return 1;
    }
        if (!strcmp(argv[0], "kill")) { // kill command
        killCmd(argv);
        return 1;
    }
    if (!strcmp(argv[0], "fg")) {   // fg, bg command
        fgbgCmd(argv);
        return 1;
    }
    if (!strcmp(argv[0], "bg")) {   // fg, bg command
        fgbgCmd(argv);
        return 1;
    }
    return 0;                     /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, char **argv, char *jobs_cmdline) 
{
    char *delim;         /* Points to first space delimiter */
    int argc;            /* Number of args */
    int bg;              /* Background job? */

    buf[strlen(buf)-1] = ' ';  /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
	buf++;

    /* Build the argv list */
    argc = 0;
    while ((delim = strchr(buf, ' '))) {
        // Ignore ', "
        if (*buf == '\'') {
            buf++;
            delim = strchr(buf, '\'');
        }
        else if (*buf == '\"') {
            buf++;
            delim = strchr(buf, '\"');
        }
	    argv[argc++] = buf;
	    *delim = '\0';
	    buf = delim + 1;
	    while (*buf && (*buf == ' ')) /* Ignore spaces */
            buf++;
    }
    argv[argc] = NULL;
    
    if (argc == 0)  /* Ignore blank line */
	return 1;

    if ((bg = (*argv[argc-1] == '&')) != 0)
	argv[--argc] = NULL;

	for(int i=0; i<argc; ++i){
		char arg[MAXLINE];
        sprintf(arg, "%s ", argv[i]);
        strcat(jobs_cmdline, arg);
	}

    return bg;
}
/* $end parseline */

// Counting argv
int argCounter(char **argv) {
    int cnt = 0;
    while(argv[cnt] != NULL) {
        cnt++;
    }
    return cnt + 1;
}

// Counting pipeline
int pipelineCounter(char **argv, int argc) {
    int cnt = 0;
    for (int i = 0; i < argc - 1; ++i) {
        if (!strcmp(argv[i], "|")) {
            cnt++;
        }
    }
    return cnt;
}

// Parsing command
char ***cmdParse(char **argv, int argc) {
    // allocate & Init
    char ***cmd = malloc(argc * sizeof(char**));
    for (int i = 0; i < argc; i++) {
        cmd[i] = malloc(MAXARGS * sizeof(char*));
        for (int j = 0; j < MAXARGS; j++) {
            cmd[i][j] = NULL;
        }
    }

    int i, j, k;
    i = j = k = 0;
    while (i < argc) {
        while (argv[i] != NULL && argv[i] != '\'' && argv[i] != '/"' && strcmp(argv[i], "|")) {
            cmd[j][k] = argv[i];
            i++;
            k++;
        }
        cmd[j][k] = NULL;
        i++;
        j++;
        k = 0;
    }
    cmd[j] = NULL;
    return cmd;
}

/* $begin job */
void jobsCmd()
{
    job_t *jobp;
    for (int i = 1; i <= MAXJOBS; i++) {
        jobp = getJobByJID(jobs, i);
		if (jobp != NULL) {
            printf("[%d] %d %s %s\n", jobp->jid, jobp->pid, state_c[jobp->state], jobp->cmdline);
		}
    }
    return;
}
/* $end job*/

/* $begin kill*/
void killCmd(char **argv)
{
    job_t *jobp;   //job pointer
    char *id = argv[1]; // next command

    // No id;
    if (id == NULL) {
        printf("Input error. kill [%%job_id] or kill [pid]\n");
        return;
    }
    // id = jobID
    else if (id[0] == '%') {
        int jid = atoi(&id[1]);
        jobp = getJobByJID(jobs, jid);
        if (jobp == NULL) {
            printf("[%%%d] No such job\n", jid);
            return;
        }
    }
    // id = pid
    else if (isdigit(id[0])) {
        pid_t pid = atoi(id);
        if (!(jobp = getJobByPID(jobs, pid))) {
            printf("[%d] No such job\n", pid);
            return;
        }
    }

    jobp->state = KILL;
    Kill(jobp->pid, SIGKILL);
    printf("success\n");

    return;
}
/* $end kill*/

/* $begin fg, bg */
void fgbgCmd(char **argv) {
    job_t *jobp;   //job pointer
    char *id = argv[1]; // next command

    // No id;
    if (id == NULL) {
        printf("Input error.\n");
        return;
    }
    // id = jobID
    else if (id[0] == '%') {
        int jid = atoi(&id[1]);
        jobp = getJobByJID(jobs, jid);
        if (jobp == NULL) {
            printf("[%%%d] No such job\n", jid);
            return;
        }
    }
    // id = pid
    else if (isdigit(id[0])) {
        pid_t pid = atoi(id);
        if (!(jobp = getJobByPID(jobs, pid))) {
            printf("%d : No such job\n", pid);
            return;
        }
    }

    //Kill(-jobp->pid, SIGCONT);

    if (!strcmp(argv[0], "fg")) {
        if (jobp->state == FG)
            printf("Job is already foreground\n");
        else {
            jobp->state = FG;
            printf("[%d] %s change %s\n", jobp->jid, jobp->cmdline, state_c[jobp->state]);
            // waiting
            while (jobp->pid == fgpid(jobs)) {
                sleep(1);
            }
        }
    }  
    if (!strcmp(argv[0], "bg")) {
        if (jobp->state == BG)
            printf("Job is already background\n");
        else {
            jobp->state = BG;
            printf("[%d] %s change %s\n", jobp->jid, jobp->cmdline, state_c[jobp->state]);
        }
    }

    return;
}
/* $end fg, bg */

void InitJob(job_t *job) {
    job->pid = 0;
    job->jid = 0;
    job->state = UNDEF;
    job->cmdline[0] = NULL;
}

int AddJob(job_t *jobs, pid_t pid, int state, char *cmdline) {
    if (pid < 1)
        return 0;
    if (next_jid > MAXJOBS) {
        printf("Too many job\n");
        return 0;
    }

    int curr_jid = next_jid;
    jobs[curr_jid].pid = pid;
    jobs[curr_jid].state = state;
    jobs[curr_jid].jid = next_jid;
    strcpy(jobs[curr_jid].cmdline, cmdline);
    printf("Add [%d] %d %s\n", jobs[curr_jid].jid, jobs[curr_jid].pid, jobs[curr_jid].cmdline);

    return 0;
}

int UpdateJob() {
    for (int i = 0; i < MAXJOBS; i++) {
        if (jobs[i].state == DONE || jobs[i].state == KILL) {
            InitJob(&jobs[i]);
        }
        if (jobs[i].state != UNDEF) {
            next_jid = i + 1;
        }
    }
}

job_t *getJobByPID(job_t *job, pid_t pid) {
    if (pid < 1) return NULL;
    for (int i = 0; i < MAXJOBS; i++) {
        if (job[i].pid == pid)
            return &job[i];
    }
    return NULL;
}

job_t *getJobByJID(job_t *job, int jid) {
    if (jid < 1) return NULL;
    for (int i = 0; i < MAXJOBS; i++) {
        if (job[i].jid == jid)
            return &job[i];
    }
    return NULL;
}

pid_t fgpid(job_t *job) {
    for (int i = 0; i < MAXJOBS; i++) {
        if (job[i].state == FG)
            return job[i].pid;
    }
    return 0;
}

void sigintHandler(int sig) {
    pid_t pid = fgpid(jobs);
    if (pid != 0) {
        if (kill(-pid, signal) < 0) {
            unix_error("kill error\n");
        }
    }
}

void sigtstpHandler(int sig) {
    pid_t pid = fgpid(jobs);
    printf("[CTRL+Z]\n");
    if (pid != 0) {
        if (kill(-pid, signal) < 0) {
            unix_error("kill error\n");
        }
    }
}

void sigchldHandler(int sig) {
    pid_t pid;
    int status;

	while ((pid = waitpid(-1, &status, WNOHANG | WCONTINUED)) > 0) {
		if (WIFEXITED(status) || WIFSIGNALED(status)) {
			for(int i = 0; i < MAXJOBS; i++) {
				if(jobs[i].pid == pid && jobs[i].state != UNDEF) {
					jobs[i].state = DONE;
					
				}
			}
		}
	}

    if (pid < 0 && errno != ECHILD) {
        unix_error("sigchld_handler waitpid error");
    }

    return;
}